<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::redirect('/', 'dashboard');

Route::namespace ('App\Http\Controllers')
    ->group(function () {
        Auth::routes([
            'login'    => true,
            'register' => false,
            'reset'    => false,
            'verify'   => false,
        ]);
    });

Route::middleware('auth')
    ->group(function () {
        Route::get('dashboard', App\Http\Controllers\DashboardController::class)
            ->name('dashboard');

        Route::middleware('is:dealer,administrator')
            ->prefix('dealer')
            ->name('dealer.')
            ->group(function () {
                Route::resource('users', App\Http\Controllers\Dealer\UserController::class);

                Route::resource('users.subscriptions', App\Http\Controllers\Dealer\User\SubscriptionOrderController::class)
                    ->only(['store']);

                Route::resource('reloads', App\Http\Controllers\Dealer\ReloadOrderController::class)
                    ->only(['index']);

                Route::resource('subscriptions', App\Http\Controllers\Dealer\SubscriptionOrderController::class)
                    ->only(['index']);

                Route::resource('transactions', App\Http\Controllers\Dealer\TransactionController::class)
                    ->only(['index']);
            });

        Route::middleware('is:administrator')
            ->prefix('administrator')
            ->name('administrator.')
            ->group(function () {
                Route::get('dashboard', App\Http\Controllers\Administrator\DashboardController::class)
                    ->name('dashboard');
            });
    });
