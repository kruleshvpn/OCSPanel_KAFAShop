<?php

namespace App\Http\Controllers\Dealer;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class SubscriptionOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $subscriptionOrders = SubscriptionOrder::query()
            ->where('dealer_id', $request->user()->getKey())
            ->with([
                'user',
            ])
            ->latest()
            ->paginate(15);

        return View::make('dealer.subscription-orders.index', [
            'subscriptionOrders' => $subscriptionOrders,
        ]);
    }
}
