<?php

namespace App\Http\Controllers\Dealer\User;

use App\Actions\DeductUserBalanceAction;
use App\Exceptions\InsufficientBalanceException;
use App\Http\Controllers\Controller;
use App\Models\Plan;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class SubscriptionOrderController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $userId)
    {
        $user = $request->user()
            ->users()
            ->findOrFail($userId);

        $request->validate([
            'plan' => [
                'required',
                'integer',
                Rule::exists(Plan::class, 'id')
                    ->whereNotNull('enabled_at'),
            ],
        ]);

        try {
            DB::transaction(function () use ($request, $user) {
                $dealer = $request->user();

                $plan = Plan::query()
                    ->findOrFail($request->plan);

                $user->update([
                    'expired_at' => $user->hasActiveSubscription() ? $user->expired_at->addDays($plan->days) : Carbon::now()->addDays($plan->days),
                ]);

                $subscriptionOrder = $user->subscriptionOrders()
                    ->create([
                        'dealer_id' => $dealer->getKey(),
                        'plan_id'   => $plan->id,
                        'days'      => $plan->days,
                        'amount'    => $plan->amount,
                    ]);

                (new DeductUserBalanceAction($request->user()))
                    ->execute($dealer, $subscriptionOrder);

                return $user;
            });
        } catch (InsufficientBalanceException $e) {
            return back()
                ->withInput()
                ->with('modal.error', $e->getMessage());
        }

        return redirect()
            ->route('dealer.users.show', [$user->getKey()])
            ->with('success', "Successfully create/extend {$user->name}'s subscription.");
    }
}
