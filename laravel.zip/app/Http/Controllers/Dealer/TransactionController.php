<?php

namespace App\Http\Controllers\Dealer;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $transactions = $request->user()->transactions()
            ->latest()
            ->paginate(15);

        return View::make('dealer.transactions.index', [
            'transactions' => $transactions,
            'prefixTypes'  => Transaction::PREFIX_TYPES,
            'types'        => Transaction::TYPES,
        ]);
    }
}
