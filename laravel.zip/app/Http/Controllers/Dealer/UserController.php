<?php

namespace App\Http\Controllers\Dealer;

use App\Actions\DeductUserBalanceAction;
use App\Exceptions\InsufficientBalanceException;
use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $users = $request->user()
            ->users()
            ->latest()
            ->paginate();

        return View::make('dealer.users.index', [
            'users' => $users,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $plans = Plan::query()
            ->enabled()
            ->get();

        return View::make('dealer.users.create', [
            'plans' => $plans,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'     => [
                'required',
                'string',
                'min:5',
            ],
            'email'    => [
                'required',
                'email',
                'max:255',
                Rule::unique(User::class),
            ],
            'password' => [
                'required',
                'string',
                'min:5',
            ],
            'plan'     => [
                'required',
                'integer',
                Rule::exists(Plan::class, 'id')
                    ->whereNotNull('enabled_at'),
            ],
        ]);

        try {
            $user = DB::transaction(function () use ($request) {
                $dealer = $request->user();

                $plan = Plan::query()
                    ->findOrFail($request->plan);

                $user = $dealer
                    ->users()
                    ->create([
                        'type'       => 'user',
                        'name'       => $request->name,
                        'email'      => $request->email,
                        'password'   => $request->password,
                        'expired_at' => Carbon::now()->addDays($plan->days),
                    ]);

                $subscriptionOrder = $user->subscriptionOrders()
                    ->create([
                        'dealer_id' => $dealer->getKey(),
                        'plan_id'   => $plan->id,
                        'days'      => $plan->days,
                        'amount'    => $plan->amount,
                    ]);

                (new DeductUserBalanceAction($request->user()))
                    ->execute($dealer, $subscriptionOrder);

                return $user;
            });
        } catch (InsufficientBalanceException $e) {
            return back()
                ->withInput($request->except('password'))
                ->with('error', $e->getMessage());
        }

        return redirect()
            ->route('dealer.users.show', [$user->getKey()])
            ->with('success', "Successfully created {$user->name}'s account.");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $userId)
    {
        $user = $request->user()
            ->users()
            ->with([
                'subscriptionOrders' => function ($query) {
                    return $query->latest();
                },
                'subscriptionOrders.plan',
            ])
            ->findOrFail($userId);

        $plans = Plan::query()
            ->enabled()
            ->get();

        return View::make('dealer.users.show', [
            'user'  => $user,
            'plans' => $plans,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $userId)
    {
        $user = $request->user()
            ->users()
            ->findOrFail($userId);

        return View::make('dealer.users.edit', [
            'user' => $user,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $userId)
    {
        $user = $request->user()
            ->users()
            ->findOrFail($userId);

        $request->validate([
            'name'     => [
                'required',
                'string',
                'min:5',
            ],
            'password' => [
                'nullable',
                'string',
                'min:5',
            ],
        ]);

        return redirect()
            ->route('dealer.users.show', [$user->getKey()])
            ->with('success', "Successfully updated {$user->name}'s account.");
    }
}
