<?php

namespace App\Models;

use App\Models\ReloadOrder;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Arr;

class User extends Authenticatable
{
    use Notifiable;

    protected $guarded = [];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $dates = [
        'expired_at',
        'last_pinged_at',
    ];

    public function is($type)
    {
        return in_array($this->type, Arr::wrap($type));
    }

    public function reloadOrders()
    {
        return $this->hasMany(ReloadOrder::class);
    }

    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function subscriptionOrders()
    {
        return $this->hasMany(SubscriptionOrder::class);
    }

    public function latestSubscriptionOrder()
    {
        return $this->subscriptionOrders()
            ->latest()
            ->first();
    }

    public function hasActiveSubscription()
    {
        if (!$this->expired_at) {
            return false;
        }

        return $this->expired_at->greaterThan(Carbon::now());
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function hasActiveConnection()
    {
        if (!$this->last_pinged_at) {
            return false;
        }

        return $this->last_pinged_at->greaterThan(now());
    }
}
