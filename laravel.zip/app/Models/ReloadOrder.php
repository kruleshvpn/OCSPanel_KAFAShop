<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReloadOrder extends Model
{
    protected $guarded = [];
}
