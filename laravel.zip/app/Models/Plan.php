<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    public $guarded = [];

    public function scopeEnabled(Builder $query)
    {
        return $query->whereNotNull('enabled_at');
    }
}
