<?php

namespace App\Models;

use App\Models\ReloadOrder;
use App\Models\SubscriptionOrder;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    const PREFIX_TYPES = [
        SubscriptionOrder::class => 'SO',
        ReloadOrder::class       => 'RO',
    ];

    const TYPES = [
        SubscriptionOrder::class => 'Subscription Order',
        ReloadOrder::class       => 'Reload Order',
    ];

    public $guarded = [];

    public function transactionable()
    {
        return $this->morphTo();
    }
}
