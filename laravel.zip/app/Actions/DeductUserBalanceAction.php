<?php

namespace App\Actions;

use App\Exceptions\InsufficientBalanceException;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class DeductUserBalanceAction
{
    /**
     * Execute the action.
     *
     * @return mixed
     */
    public function execute(User $user, Model $model)
    {
        DB::transaction(function () use ($user, $model) {
            $user = User::query()
                ->lockForUpdate()
                ->findOrFail($user->getKey());

            if ($user->balance < $model->amount) {
                throw new InsufficientBalanceException("Your balance is insufficient to perform the action.");
            }

            $transaction = $user->transactions()
                ->make([
                    'initial' => $user->balance,
                    'in'      => 0,
                    'out'     => $model->amount,
                    'balance' => $user->balance - $model->amount,
                ]);

            $transaction->transactionable()->associate($model);

            $transaction->save();

            $user->decrement('balance', $transaction->out);

            return $transaction;
        });
    }
}
