@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Transactions') }}</div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Order Type</th>
                                <th scope="col">Order ID</th>
                                <th scope="col">Initial</th>
                                <th scope="col">In</th>
                                <th scope="col">Out</th>
                                <th scope="col">Balance</th>
                                <th scope="col">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($transactions as $transaction)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>{{ $types[$transaction->transactionable_type] }}</td>
                                <td>{{ $prefixTypes[$transaction->transactionable_type] }}-{{ $transaction->transactionable_id }}</td>
                                <td>RM{{ number_format($transaction->initial / 100, 2) }}</td>
                                <td>RM{{ number_format($transaction->in / 100, 2) }}</td>
                                <td>RM{{ number_format($transaction->out / 100, 2) }}</td>
                                <td>RM{{ number_format($transaction->balance / 100, 2) }}</td>
                                <td>{{ $transaction->created_at }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="float-right">
                        {{ $transactions->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
