@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Subscription Orders') }}</div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">User</th>
                                <th scope="col">Subscription Order ID</th>
                                <th scope="col">Plan</th>
                                <th scope="col">Days</th>
                                <th scope="col">Price</th>
                                <th scope="col">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($subscriptionOrders as $subscriptionOrder)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>{{ $subscriptionOrder->user->name }}</td>
                                <td>SO-{{ $subscriptionOrder->id }}</td>
                                <td>{{ $subscriptionOrder->plan->name }}</td>
                                <td>{{ $subscriptionOrder->days }} {{ Str::plural('day', $subscriptionOrder->days) }}</td>
                                <td>RM{{ number_format($subscriptionOrder->amount / 100, 2) }}</td>
                                <td>{{ $subscriptionOrder->created_at }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="float-right">
                        {{ $subscriptionOrders->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
