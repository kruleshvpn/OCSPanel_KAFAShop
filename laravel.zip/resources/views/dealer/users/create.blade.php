@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">{{ __('Create User') }}</div>

                <div class="card-body">
                    <x-alert />
                    <form action="{{ route('dealer.users.store') }}" method="POST">
                        @csrf

                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" id="name" placeholder="John" value="{{ old('name') }}" required>
                            <div class="invalid-feedback">
                                {{ $errors->first('name') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" id="email" placeholder="john@email.com" value="{{ old('email') }}" required>
                            <div class="invalid-feedback">
                                {{ $errors->first('email') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" id="password" placeholder="••••••••••" value="{{ old('password') }}" required>
                            <div class="invalid-feedback">
                                {{ $errors->first('password') }}
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="plan">Plan</label>
                            <select id="plan" name="plan" class="custom-select {{ $errors->has('plan') ? 'is-invalid' : '' }}" required>
                                <option value="">Please choose a plan..</option>
                                @foreach($plans as $plan)
                                    <option value="{{ $plan->id }}" {{ (int) old('plan') === $plan->id ?'selected' : '' }}>{{ $plan->name }} / {{ $plan->days }} {{ Str::plural('day', $plan->days) }} / RM{{ number_format($plan->amount / 100,2) }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback">
                                {{ $errors->first('plan') }}
                            </div>
                        </div>
                        <button type="submit" class="float-right btn btn-primary">Create</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
