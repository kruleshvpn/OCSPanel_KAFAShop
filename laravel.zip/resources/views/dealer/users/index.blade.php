@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    {{ __('Users') }}
                    <div class="float-right">
                        <a href="{{ route('dealer.users.create') }}" class="btn btn-sm btn-primary">Create User</a>
                    </div>
                </div>

                <div class="card-body">
                    <x-alert />
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">VPN Status</th>
                                <th scope="col">Status</th>
                                <th scope="col">Expired At</th>
                                <th scope="col">Created At</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    <span class="badge badge-{{ $user->hasActiveConnection() ? 'success' : 'danger' }}">{{ $user->hasActiveConnection() ? 'Online' : 'Offline' }}</span>
                                </td>
                                <td>
                                    <span class="badge badge-{{ $user->hasActiveSubscription() ? 'success' : 'danger' }}">{{ $user->hasActiveSubscription() ? 'Active' : 'Expired' }}</span>
                                </td>
                                <td>{{ $user->hasActiveSubscription() ? $user->expired_at : '—' }}</td>
                                <td>{{ $user->created_at }}</td>
                                <td>
                                    <a href="{{ route('dealer.users.edit', [$user->id]) }}" class="btn btn-sm btn-link">Edit</a>
                                    <a href="{{ route('dealer.users.show', [$user->id]) }}" class="btn btn-sm btn-link">Show</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="float-right">
                        {{ $users->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
