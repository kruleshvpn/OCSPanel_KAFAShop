@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center mb-4">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    View {{ $user->name }}'s account
                </div>

                <div class="card-body">
                    <x-alert />
                    <dl class="row">
                        <dt class="col-sm-3">Name</dt>
                        <dd class="col-sm-9">{{ $user->name }}</dd>
                        <dt class="col-sm-3">Email</dt>
                        <dd class="col-sm-9">{{ $user->email }}</dd>
                        <dt class="col-sm-3">VPN Status</dt>
                        <dd class="col-sm-9">
                            <span class="badge badge-{{ $user->hasActiveConnection() ? 'success' : 'danger' }}">{{ $user->hasActiveConnection() ? 'Online' : 'Offline' }}</span>
                        </dd>
                        <dt class="col-sm-3">Status</dt>
                        <dd class="col-sm-9">
                            <span class="badge badge-{{ $user->hasActiveSubscription() ? 'success' : 'danger' }}">{{ $user->hasActiveSubscription() ? 'Active' : 'Expired' }}</span>
                        </dd>
                        <dt class="col-sm-3">Expired At</dt>
                        <dd class="col-sm-9">{{ $user->hasActiveSubscription() ? $user->expired_at : '—' }}</dd>
                        <dt class="col-sm-3">Created At</dt>
                        <dd class="col-sm-9">{{ $user->created_at }}</dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
     <div class="row justify-content-center mb-4">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    Subscriptions Orders
                    <div class="float-right">
                        <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#subscription">{{ $user->hasActiveSubscription() ? 'Extend' : 'Renew' }} Subscription</button>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Subscription Order ID</th>
                                <th scope="col">Plan</th>
                                <th scope="col">Days</th>
                                <th scope="col">Price</th>
                                <th scope="col">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($user->subscriptionOrders as $subscriptionOrder)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>SO-{{ $subscriptionOrder->id }}</td>
                                <td>{{ $subscriptionOrder->plan->name }}</td>
                                <td>{{ $subscriptionOrder->days }} {{ Str::plural('day', $subscriptionOrder->days) }}</td>
                                <td>RM{{ number_format($subscriptionOrder->amount / 100, 2) }}</td>
                                <td>{{ $subscriptionOrder->created_at }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="subscription" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">{{ $user->hasActiveSubscription() ? 'Extend' : 'Renew' }} Subscription</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <x-alert suffix="modal" />
        <form action="{{ route('dealer.users.subscriptions.store', [$user->id]) }}" method="POST">
            @csrf

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control disabled" id="name" placeholder="John" value="{{ $user->name }}" disabled>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control disabled" id="email" placeholder="john@email.com" value="{{ $user->email  }}" disabled>
            </div>
            <div class="form-group">
                <label for="plan">Plan</label>
                <select id="plan" name="plan" class="custom-select {{ $errors->has('plan') ? 'is-invalid' : '' }}" required>
                    <option value="">Please choose a plan..</option>
                    @foreach($plans as $plan)
                        <option value="{{ $plan->id }}" {{ (int) old('plan') === $plan->id ?'selected' : '' }}>{{ $plan->name }} / {{ $plan->days }} {{ Str::plural('day', $plan->days) }} / RM{{ number_format($plan->amount / 100,2) }}</option>
                    @endforeach
                </select>
                <div class="invalid-feedback">
                    {{ $errors->first('plan') }}
                </div>
            </div>
            <button type="submit" class="float-right btn btn-primary">{{ $user->hasActiveSubscription() ? 'Extend' : 'Renew' }}</button>
        </form>
      </div>
    </div>
  </div>
</div>

@if($errors->any() || session('modal.error'))
<script type="text/javascript">
    $(document).ready(function(){
        $('#subscription').modal('show')
    });
</script>
@endif
@endsection
