@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Reload Orders') }}</div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Reload Order ID</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Remarks</th>
                                <th scope="col">Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($reloadOrders as $reloadOrder)
                            <tr>
                                <th scope="row">{{ $loop->iteration }}</th>
                                <td>RO-{{ $reloadOrder->id }}</td>
                                <td>RM{{ number_format($reloadOrder->amount, 2) }}</td>
                                <td>{{ $reloadOrder->remarks }}</td>
                                <td>{{ $reloadOrder->created_at }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="float-right">
                        {{ $reloadOrders->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
