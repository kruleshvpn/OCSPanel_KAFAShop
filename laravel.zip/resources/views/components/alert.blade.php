<div>
    @if (session($suffix . 'success'))
        <div class="alert alert-success" role="alert">
            {{ session($suffix . 'success') }}
        </div>
    @endif
    @if (session($suffix . 'error'))
        <div class="alert alert-danger" role="alert">
            {{ session($suffix . 'error') }}
        </div>
    @endif
</div>
